# Module AI/ — Agent d'investigation autonome

> Analyse automatique de comptes, médias, narratives et campagnes suspects.  
> Produit un rapport Markdown structuré à partir des données du pipeline AI-FORENSICS.

Ce module est une **solution parallèle** — il ne modifie aucun worker existant. Il se branche en **lecture seule** sur MongoDB et Neo4j pour exploiter les données déjà produites par le pipeline.

> ⚠️ **Données potentiellement partielles.** Le scrapping sur lequel repose toute analyse n'est pas nécessairement exhaustif. Les données disponibles représentent un échantillon de l'activité réelle — il existe probablement des comptes, posts, médias et relations non capturés. Tous les rapports générés mentionnent cette limitation systématiquement.

---

## Table des matières

1. [Vue d'ensemble](#1-vue-densemble)
2. [Architecture](#2-architecture)
3. [Installation](#3-installation)
4. [Configuration](#4-configuration)
5. [Utilisation](#5-utilisation)
6. [Fichiers du module](#6-fichiers-du-module)
7. [Fonctionnement interne](#7-fonctionnement-interne)
8. [Interprétation des rapports](#8-interprétation-des-rapports)
9. [Glossaire](#9-glossaire)
10. [Limites et précautions](#10-limites-et-précautions)

---

## 1. Vue d'ensemble

L'agent d'investigation fonctionne en deux phases :

**Phase 1 — Collecte déterministe** : les données sont collectées directement en Python selon une séquence fixe adaptée au point d'entrée (compte, narrative ou campagne). Aucune décision n'est déléguée au LLM à cette étape.

**Phase 2 — Rédaction par le LLM** : les données collectées sont résumées et transmises au modèle de langage, qui rédige le rapport en français à partir des valeurs réelles. Le LLM n'invente pas de données — il structure et interprète ce qui lui est fourni.

Cette architecture en deux phases garantit que le rapport contient uniquement des valeurs issues de la base de données, indépendamment du modèle LLM utilisé.

---

## 2. Architecture

```
CLI (--account / --narrative / --campaign / --post)
    │
    ▼
investigation_agent.py
    │
    ├── Phase 1 : collecte déterministe (tools.py)
    │     ├── get_account_info          → MongoDB accounts
    │     ├── get_account_posts         → MongoDB posts
    │     ├── get_media_scores          → MongoDB media
    │     ├── get_graph_neighbors       → Neo4j (communauté, hashtags, doublons)
    │     ├── get_narrative             → MongoDB narratives
    │     ├── get_campaign_signals      → MongoDB campaigns
    │     ├── get_campaign_graph        → Neo4j (comptes, hashtags, doublons cross-comptes)
    │     ├── get_temporal_analysis     → Neo4j (propagation, cadence, silences, cross-campagne)
    │     └── search_accounts_by_narrative → MongoDB posts + accounts
    │
    ├── Calcul du score de suspicion global (Python pur)
    │
    ├── Phase 2 : rédaction du rapport (LLM)
    │
    └── Rapport Markdown → AI-FORENSICS/reports/<timestamp>_<type>_<cible>.md
```

**Séquences de collecte selon le point d'entrée :**

| Point d'entrée | Séquence d'outils |
|---|---|
| `--account` | get_account_info → get_account_posts → get_media_scores → get_graph_neighbors → get_narrative (×N) → get_temporal_analysis |
| `--narrative` | get_narrative → search_accounts_by_narrative → get_account_info + get_media_scores (top 2) → get_temporal_analysis |
| `--campaign` | get_campaign_signals → get_campaign_graph → get_temporal_analysis → get_account_info + get_media_scores (top 2) |
| `--post` | résolution account_id → séquence compte |

---

## 3. Installation

```bash
conda create -n AI_agent python=3.11
conda activate AI_agent
pip install -r AI/requirements_ai.txt
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.1:8b
```

**Dépendances principales :**
```
langchain>=0.2.0
langchain-community>=0.2.0
langchain-ollama>=0.1.0
langgraph>=0.2.0
pydantic>=2.0.0
ollama>=0.2.0
```

---

## 4. Configuration

Ajouter au fichier `.env` existant :

```env
AI_PROVIDER=ollama          # ollama | groq | anthropic
AI_MODEL=llama3.1:8b
AI_BASE_URL=http://localhost:11434
AI_API_KEY=                 # pour groq ou anthropic
AI_REPORTS_DIR=./reports
AI_TEMPERATURE=0.2
```

**Providers alternatifs (meilleure qualité de rédaction) :**

```env
# Groq (gratuit, modèle 70B)
AI_PROVIDER=groq
AI_MODEL=llama-3.1-70b-versatile
AI_API_KEY=gsk_...

# Anthropic
AI_PROVIDER=anthropic
AI_MODEL=claude-sonnet-4-20250514
AI_API_KEY=sk-ant-...
```

---

## 5. Utilisation

```bash
conda activate AI_agent
cd ~/AI-FORENSICS/AI

# Analyser un compte (par handle ou platform_id)
python investigation_agent.py --account nolimitmoneyy0 --platform tiktok
python investigation_agent.py --account MS4wLjAB... --platform tiktok

# Analyser une narrative
python investigation_agent.py --narrative 69d2774d7dc202593e1b35fa

# Analyser une campagne détectée
python investigation_agent.py --campaign 69d504d00b27a5d21ee8f65b

# Analyser à partir d'un post
python investigation_agent.py --post <post_mongo_id>

# Options avancées
python investigation_agent.py --account nolimitmoneyy0 --platform tiktok \
    --output ~/AI-FORENSICS/reports --provider groq --verbose

# Afficher sans sauvegarder
python investigation_agent.py --account nolimitmoneyy0 --platform tiktok --no-save
```

**Recherche de compte flexible :** l'agent accepte le `display_name`, le `username` numérique ou le `platform_id` long. La recherche tente les trois champs automatiquement.

---

## 6. Fichiers du module

```
AI-FORENSICS/AI/
├── investigation_agent.py   ← orchestration, CLI, collecte, rédaction LLM
├── tools.py                 ← outils de lecture MongoDB + Neo4j
├── prompts.py               ← system prompt, templates, helpers scoring
├── requirements_ai.txt      ← dépendances spécifiques
└── README_AI.md             ← ce fichier

AI-FORENSICS/reports/        ← rapports générés (créé automatiquement)
```

---

## 7. Fonctionnement interne

### tools.py — Outils de collecte

**Tests individuels :**
```bash
python tools.py --test-account tiktok nolimitmoneyy0
python tools.py --test-posts 69d276e34796706f8e7149ac
python tools.py --test-media 69d276e34796706f8e7149ac
python tools.py --test-neighbors MS4wLjABAAAAy3Pi...
python tools.py --test-narrative 69d2774d7dc202593e1b35fa
```

**Relations Neo4j utilisées (noms réels du worker réseau) :**

| Relation | Signification |
|---|---|
| `A_PUBLIÉ` | Account → Post |
| `APPARTIENT_À` | Post → Narrative |
| `HAS_HASHTAG` | Post → Hashtag |
| `EST_DOUBLON_DE` | Post → Post (contenu dupliqué) |
| `COUVRE` | Campaign → Narrative |

**Propriétés clés sur les nœuds :**

| Nœud | Propriétés utiles |
|---|---|
| `Account` | `display_name`, `platform_id`, `community_id`, `pagerank_score`, `is_suspicious` |
| `Post` | `published_at`, `deepfake_score`, `is_synthetic`, `is_duplicate`, `sentiment_label` |
| `Narrative` | `label`, `keywords`, `post_count` |
| `Campaign` | `name`, `score`, `signals`, `platforms` |
| `Hashtag` | `name` |

### get_temporal_analysis — Analyse temporelle complète

Cet outil effectue 9 analyses distinctes sur le graphe Neo4j :

1. **Timeline** — posts par jour par compte
2. **Co-occurrences** — jours où plusieurs comptes publient simultanément
3. **Cadence** — moyenne et max de posts/jour par compte
4. **Évolution mensuelle** — avec score deepfake moyen par mois
5. **Propagation** — ordre chronologique d'entrée des comptes
6. **Compte semence** — premier compte à publier sur la narrative
7. **Silences suspects** — gaps > 14 jours par compte
8. **Corrélation deepfake × temporel** — mois avec pic deepfake au-dessus de la moyenne
9. **Cross-campagne** — comptes actifs sur plusieurs campagnes simultanément

### get_campaign_graph — Graphe complet d'une campagne

Traverse le chemin `Campaign → COUVRE → Narrative → APPARTIENT_À → Post → A_PUBLIÉ → Account` pour remonter tous les comptes impliqués avec leurs stats deepfake, les hashtags dominants et les relations de duplication entre comptes.

---

## 8. Interprétation des rapports

### Scores deepfake

| Modèle | Mécanisme | Générateurs couverts |
|---|---|---|
| `sdxl-detector` | CNN diffusion | SD/SDXL, FLUX partiel |
| `swinv2-openfake` | SwinV2 fine-tuné (F1=0.943) | FLUX, Midjourney v6, DALL-E 3, Grok-2 |
| `synthbuster` | Fourier/sklearn | Artefacts spectraux |

**Seuils :**

| Score | Prédiction |
|---|---|
| 0.00 – 0.45 | `likely_real` — probablement authentique |
| 0.45 – 0.65 | `suspicious` — vérification manuelle recommandée |
| 0.65 – 1.00 | `synthetic` — probablement généré par IA |

**Pattern courant sur vidéos compressées :** `sdxl-detector` élevé (> 0.9) + `swinv2-openfake` bas (< 0.1) = forte divergence inter-modèles = vidéo réelle avec compression agressive. Ne pas interpréter comme un signal d'alerte.

### Score de suspicion global

Valeur calculée en Python (indépendante du LLM) combinant score deepfake moyen, ratio synthétique, signaux des narratives, et bonus si campagne ou médias réutilisés détectés.

### Niveau de confiance

Reflète la fiabilité des scores deepfake selon la divergence inter-modèles :
- **Élevé** : divergence < 0.15 (modèles concordants)
- **Moyen** : divergence 0.15–0.30
- **Faible** : divergence > 0.30 (vérification manuelle requise)

### Requêtes Cypher suggérées

Chaque rapport inclut une section **Requêtes Cypher suggérées** contenant des requêtes exploitables directement dans Neo4j Browser pour approfondir l'investigation. Exemples typiques pour une campagne :

```cypher
// Propagation chronologique des posts d'une campagne
MATCH (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)<-[:A_PUBLIÉ]-(a:Account)
WHERE c.mongo_id = '<id>'
RETURN a.display_name, p.published_at, p.text
ORDER BY p.published_at

// Doublons entre comptes
MATCH (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)
      -[:EST_DOUBLON_DE]->(orig:Post)<-[:A_PUBLIÉ]-(orig_acc:Account)
WHERE c.mongo_id = '<id>'
MATCH (p)<-[:A_PUBLIÉ]-(copy_acc:Account)
RETURN copy_acc.display_name, orig_acc.display_name, count(*) AS copies
ORDER BY copies DESC

// Réseau de la campagne (visualisation graphe)
MATCH path = (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)<-[:A_PUBLIÉ]-(a:Account)
WHERE c.mongo_id = '<id>'
RETURN path LIMIT 100
```

---

## 9. Glossaire

**Cadence robotique** : rythme de publication quasi-mécanique, typiquement ≥ 1 post par jour sur plus de 20 jours consécutifs sans interruption notable. Chez un humain, la publication est irrégulière (absences le week-end, silences pendant les vacances, pics liés à l'actualité). Une cadence robotique suggère une automatisation ou une gestion professionnelle du compte.

**Compte semence** : premier compte à avoir publié sur une narrative donnée. Dans une campagne de désinformation, ce compte est souvent la source qui "donne le signal" aux autres amplificateurs. Il est généralement le plus ancien, le plus actif, et le plus important à investiguer en priorité.

**Co-occurrence temporelle** : situation où plusieurs comptes publient le même jour sur la même narrative. Une co-occurrence isolée peut être une coïncidence (réaction à l'actualité). Des co-occurrences répétées entre les mêmes comptes constituent un signal de coordination.

**Silence suspect** : interruption de publication de plus de 14 jours pour un compte à cadence régulière, suivie d'une reprise avec la même cadence. Peut indiquer une rotation de gestionnaire, une maintenance technique du compte, ou une suspension temporaire sur la plateforme.

**Divergence inter-modèles** : écart entre les scores des trois modèles deepfake. Une divergence élevée (> 0.30) indique que les modèles ne s'accordent pas — le résultat est peu fiable et nécessite une vérification manuelle. Une divergence faible (< 0.15) indique une forte concordance.

**Amplificateur cross-campagne** : compte actif simultanément sur plusieurs campagnes détectées. Peut indiquer un rôle d'infrastructure partagée entre différentes opérations d'influence, ou simplement un créateur de contenu prolifique sur des thèmes voisins.

**PageRank** : score de centralité calculé par Neo4j GDS sur le graphe des relations. Un PageRank élevé indique un compte qui reçoit beaucoup de connexions depuis des comptes eux-mêmes bien connectés — souvent les amplificateurs clés d'un réseau.

**Communauté Louvain** : groupe de comptes densément interconnectés détecté par l'algorithme de Louvain (Neo4j GDS). Des comptes d'une même communauté qui publient sur la même narrative constituent un signal de coordination structurel.

**Données partielles** : le scrapping utilisé pour alimenter la base de données n'est pas exhaustif. Seuls les comptes et posts explicitement collectés sont analysés. Des comptes amplificateurs, des médias réutilisés ou des relations entre comptes peuvent exister sans être visibles dans l'analyse.

---

## 10. Limites et précautions

**Disclaimer obligatoire.** Tout rapport mentionne qu'il nécessite une vérification humaine. L'agent est un outil d'aide à l'analyse, pas un système de décision autonome.

**Données partielles.** Le scrapping n'étant pas exhaustif, les signaux détectés (ratio synthétique, nombre de doublons, co-occurrences) peuvent être sous-estimés par rapport à la réalité. Une absence de signal n'est pas une preuve d'absence de coordination.

**Lecture seule stricte.** L'agent ne modifie jamais MongoDB ni Neo4j.

**Relation campagne Neo4j.** Le chemin `Account → campagne` passe par `Account → Post → Narrative → Campaign` (via `COUVRE`). Il n'existe pas de relation directe `Account → Campaign` dans le schéma actuel.

**Qualité du LLM.** `llama3.1:8b` produit des rapports corrects mais peut parfois reformuler maladroitement des valeurs numériques ou abréger les requêtes Cypher. Pour de meilleurs rapports, utiliser Groq (`llama-3.1-70b-versatile`, gratuit) ou Anthropic.

**Calibration v4 en attente.** Les biais et poids des modèles deepfake dans `ai_forensics.cfg` doivent être recalibrés. Tant que la calibration n'a pas tourné, les poids de SwinV2 sont à 0.50 (neutre), ce qui sous-exploite sa performance réelle (F1=0.943).

---

*Module développé avec l'aide de Claude — Anthropic*  
*Telecom Paris — Mastère spécialisé Cyberdéfense / Cybersécurité*  
*Cours CYBER721 — Réseaux et Organisation de données : intelligence et sécurité*

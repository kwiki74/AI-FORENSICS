"""investigation_agent.py
========================
Agent d'investigation AI-FORENSICS.

Analyse automatique de comptes, posts, narratives ou campagnes suspects
en combinant lecture MongoDB/Neo4j (tools.py) et raisonnement LLM (LangChain).
Produit un rapport Markdown dans AI-FORENSICS/reports/.

Usage :
    python investigation_agent.py --account nolimitmoneyy0 --platform tiktok
    python investigation_agent.py --narrative 69d2774d7dc202593e1b35fa
    python investigation_agent.py --campaign <campaign_id>
    python investigation_agent.py --account nolimitmoneyy0 --platform tiktok \\
        --output ./reports/ --model llama3.1:8b --verbose

Variables d'environnement (.env) :
    AI_PROVIDER=ollama          # ollama | groq | anthropic
    AI_MODEL=llama3.1:8b
    AI_BASE_URL=http://localhost:11434
    AI_API_KEY=                 # pour groq / anthropic
    AI_REPORTS_DIR=./reports
    AI_MAX_TOKENS=4096
    AI_TEMPERATURE=0.2

Dépendances :
    pip install langchain langchain-community langchain-ollama \\
                langchain-groq langchain-anthropic ollama python-dotenv
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Chargement .env
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

# ---------------------------------------------------------------------------
# Import des modules locaux (même dossier AI/)
# ---------------------------------------------------------------------------
_AI_DIR = Path(__file__).resolve().parent
if str(_AI_DIR) not in sys.path:
    sys.path.insert(0, str(_AI_DIR))

from tools import (                          # noqa: E402
    get_account_info,
    get_account_posts,
    get_media_scores,
    get_graph_neighbors,
    get_narrative,
    get_campaign_signals,
    get_campaign_graph,
    get_temporal_analysis,
    search_accounts_by_narrative,
    TOOLS_SCHEMA,
)
from prompts import (                        # noqa: E402
    build_system_prompt,
    build_initial_query,
    score_to_label,
    divergence_to_confidence,
    CONFIDENCE_LABELS,
)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-8s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("ai_forensics.agent")


# ===========================================================================
# Configuration LLM
# ===========================================================================

def _get_env(key: str, default: str = "") -> str:
    return os.getenv(key, default).strip()


class AgentConfig:
    """Lit la configuration LLM depuis les variables d'environnement."""

    provider:     str
    model:        str
    base_url:     str
    api_key:      str
    max_tokens:   int
    temperature:  float
    reports_dir:  Path

    def __init__(
        self,
        provider:    Optional[str] = None,
        model:       Optional[str] = None,
        output_dir:  Optional[str] = None,
        temperature: Optional[float] = None,
    ):
        self.provider    = provider    or _get_env("AI_PROVIDER",    "ollama")
        self.model       = model       or _get_env("AI_MODEL",       "llama3.1:8b")
        self.base_url    = _get_env("AI_BASE_URL", "http://localhost:11434")
        self.api_key     = _get_env("AI_API_KEY",  "")
        self.max_tokens  = int(_get_env("AI_MAX_TOKENS", "4096"))
        self.temperature = temperature if temperature is not None else float(_get_env("AI_TEMPERATURE", "0.2"))

        reports_raw      = output_dir or _get_env("AI_REPORTS_DIR", "")
        if reports_raw:
            self.reports_dir = Path(reports_raw).expanduser().resolve()
        else:
            self.reports_dir = Path(__file__).resolve().parent.parent / "reports"

    def __repr__(self) -> str:
        return (
            f"AgentConfig(provider={self.provider}, model={self.model}, "
            f"temperature={self.temperature}, reports_dir={self.reports_dir})"
        )


# ===========================================================================
# Construction du LLM LangChain
# ===========================================================================

def build_llm(cfg: AgentConfig):
    """
    Instancie le LLM LangChain selon le provider configuré.

    Providers supportés : ollama | groq | anthropic
    """
    provider = cfg.provider.lower()

    if provider == "ollama":
        try:
            from langchain_ollama import ChatOllama
        except ImportError:
            from langchain_community.chat_models import ChatOllama  # fallback

        logger.info(f"LLM : Ollama — {cfg.model} @ {cfg.base_url}")
        return ChatOllama(
            model       = cfg.model,
            base_url    = cfg.base_url,
            temperature = cfg.temperature,
            num_predict = cfg.max_tokens,
        )

    elif provider == "groq":
        from langchain_groq import ChatGroq
        if not cfg.api_key:
            raise ValueError("AI_API_KEY requis pour le provider groq")
        logger.info(f"LLM : Groq — {cfg.model}")
        return ChatGroq(
            model_name  = cfg.model,
            api_key     = cfg.api_key,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
        )

    elif provider == "anthropic":
        from langchain_anthropic import ChatAnthropic
        if not cfg.api_key:
            raise ValueError("AI_API_KEY requis pour le provider anthropic")
        logger.info(f"LLM : Anthropic — {cfg.model}")
        return ChatAnthropic(
            model_name  = cfg.model,
            api_key     = cfg.api_key,
            temperature = cfg.temperature,
            max_tokens  = cfg.max_tokens,
        )

    else:
        raise ValueError(f"Provider LLM inconnu : {cfg.provider}. Valeurs acceptées : ollama | groq | anthropic")


# ===========================================================================
# Construction des outils LangChain
# ===========================================================================

def build_langchain_tools() -> list:
    """
    Enveloppe les fonctions de tools.py dans des StructuredTool LangChain.
    Utilise TOOLS_SCHEMA pour les descriptions et signatures.
    """
    from langchain_core.tools import StructuredTool
    from pydantic import BaseModel, Field, create_model

    lc_tools = []

    # Mapping nom → fonction Python
    _fn_map = {
        "get_account_info":             get_account_info,
        "get_account_posts":            get_account_posts,
        "get_media_scores":             get_media_scores,
        "get_graph_neighbors":          get_graph_neighbors,
        "get_narrative":                get_narrative,
        "get_campaign_signals":         get_campaign_signals,
        "search_accounts_by_narrative": search_accounts_by_narrative,
    }

    # Mapping type JSON Schema → type Python
    _type_map = {"string": str, "integer": int, "number": float, "boolean": bool}

    for schema in TOOLS_SCHEMA:
        name        = schema["name"]
        description = schema["description"]
        props       = schema["parameters"].get("properties", {})
        required    = schema["parameters"].get("required", [])
        fn          = _fn_map[name]

        # Construction dynamique du modèle Pydantic pour les arguments
        fields = {}
        for param_name, param_def in props.items():
            py_type = _type_map.get(param_def.get("type", "string"), str)
            if param_name not in required:
                py_type = Optional[py_type]
                fields[param_name] = (py_type, Field(default=None, description=param_def.get("description", "")))
            else:
                fields[param_name] = (py_type, Field(description=param_def.get("description", "")))

        ArgsModel = create_model(f"{name}_args", **fields)

        # Wrapper qui sérialise le résultat en JSON lisible par le LLM
        def make_wrapper(f):
            def wrapper(**kwargs):
                # Retire les arguments None optionnels
                kwargs = {k: v for k, v in kwargs.items() if v is not None}
                try:
                    result = f(**kwargs)
                    return json.dumps(result, ensure_ascii=False, indent=2, default=str)
                except Exception as exc:
                    logger.error(f"Erreur outil {f.__name__} : {exc}", exc_info=True)
                    return json.dumps({"error": str(exc), "tool": f.__name__})
            wrapper.__name__ = f.__name__
            return wrapper

        lc_tools.append(
            StructuredTool(
                name        = name,
                description = description,
                func        = make_wrapper(fn),
                args_schema = ArgsModel,
            )
        )

    logger.info(f"{len(lc_tools)} outils LangChain construits")
    return lc_tools


# ===========================================================================
# Agent ReAct
# ===========================================================================

def _collect_account(entry_value: str, platform: str, neo4j_available: bool) -> dict:
    """Collecte déterministe pour un point d'entrée compte."""
    data = {}
    logger.info("Collecte : get_account_info")
    info = get_account_info(platform, entry_value)

    # Fallback : si non trouvé par username, cherche par display_name dans MongoDB
    if "error" in info:
        logger.info(f"Recherche par username échouée, tentative par display_name...")
        try:
            from tools import _get_db
            db = _get_db()
            acc = db.accounts.find_one(
                {"platform": platform, "display_name": entry_value},
                {"platform_id": 1, "username": 1}
            )
            if acc:
                alt_id = acc.get("username") or acc.get("platform_id")
                logger.info(f"Compte trouvé via display_name → username={alt_id}")
                info = get_account_info(platform, alt_id)
            else:
                # Dernière tentative : recherche insensible à la casse
                import re
                acc = db.accounts.find_one(
                    {"platform": platform,
                     "display_name": {"$regex": f"^{re.escape(entry_value)}$", "$options": "i"}},
                    {"platform_id": 1, "username": 1}
                )
                if acc:
                    alt_id = acc.get("username") or acc.get("platform_id")
                    logger.info(f"Compte trouvé via display_name (insensible casse) → {alt_id}")
                    info = get_account_info(platform, alt_id)
        except Exception as e:
            logger.warning(f"Fallback display_name échoué : {e}")

    data["account"] = info
    if "error" in info:
        logger.warning(f"Compte introuvable : {info['error']}")
        return data

    account_id  = info.get("account_id")
    platform_id = info.get("platform_id")

    logger.info("Collecte : get_account_posts")
    data["posts"] = get_account_posts(account_id, limit=20)

    logger.info("Collecte : get_media_scores")
    data["media"] = get_media_scores(account_id)

    if neo4j_available and platform_id:
        logger.info("Collecte : get_graph_neighbors")
        data["graph"] = get_graph_neighbors(platform_id, depth=2)

    # Narratives identifiées dans les posts
    narrative_ids = list({
        p["nlp"]["narrative_id"]
        for p in data.get("posts", [])
        if p.get("nlp", {}).get("narrative_id")
    })
    data["narratives"] = []
    for nid in narrative_ids[:3]:  # max 3 narratives
        logger.info(f"Collecte : get_narrative({nid[:8]}...)")
        data["narratives"].append(get_narrative(nid))

    # Campagnes
    campaign_ids = info.get("flags", {}).get("campaign_ids", [])
    data["campaigns"] = []
    for cid in campaign_ids[:2]:  # max 2 campagnes
        logger.info(f"Collecte : get_campaign_signals({cid[:8]}...)")
        data["campaigns"].append(get_campaign_signals(cid))

    # Analyse temporelle du compte (via platform_id pour les requêtes Neo4j)
    if platform_id:
        logger.info("Collecte : get_temporal_analysis (account)")
        data["temporal"] = get_temporal_analysis(platform_id, entry_type="account")
    return data


def _collect_narrative(entry_value: str, neo4j_available: bool) -> dict:
    """Collecte déterministe pour un point d'entrée narrative."""
    data = {}
    logger.info("Collecte : get_narrative")
    data["narrative"] = get_narrative(entry_value)

    logger.info("Collecte : search_accounts_by_narrative")
    accounts_list = search_accounts_by_narrative(entry_value)
    data["accounts_list"] = accounts_list

    # Détaille les 2 comptes les plus actifs
    data["accounts_detail"] = []
    for acc in accounts_list[:2]:
        aid = acc.get("account_id")
        plat = acc.get("platform", "tiktok")
        if aid:
            logger.info(f"Collecte : get_account_info({acc.get('username', aid[:8])})")
            info = get_account_info(plat, acc.get("username") or aid)
            data["accounts_detail"].append({
                "info":  info,
                "media": get_media_scores(aid),
            })
    # Analyse temporelle de la narrative
    if entry_value:
        logger.info("Collecte : get_temporal_analysis (narrative)")
        data["temporal"] = get_temporal_analysis(entry_value, entry_type="narrative")
    return data


def _collect_campaign(entry_value: str) -> dict:
    """Collecte déterministe pour un point d'entrée campagne."""
    data = {}

    logger.info("Collecte : get_campaign_signals")
    data["campaign"] = get_campaign_signals(entry_value)

    logger.info("Collecte : get_campaign_graph (Neo4j)")
    data["campaign_graph"] = get_campaign_graph(entry_value)

    logger.info("Collecte : get_temporal_analysis (campaign)")
    data["temporal"] = get_temporal_analysis(entry_value, entry_type="campaign")

    # Détaille les 2 comptes les plus actifs (depuis le graphe Neo4j si disponible)
    data["accounts_detail"] = []
    graph_accounts = (data["campaign_graph"].get("accounts") or [])[:2]
    if graph_accounts:
        for acc in graph_accounts:
            uid  = acc.get("username") or acc.get("platform_id")
            plat = acc.get("platform", "tiktok")
            if uid:
                logger.info(f"Collecte : get_account_info({uid})")
                info = get_account_info(plat, uid)
                if "error" not in info:
                    data["accounts_detail"].append({
                        "info":  info,
                        "media": get_media_scores(info.get("account_id", "")),
                    })
    else:
        # Fallback MongoDB si Neo4j vide
        for acc in (data["campaign"].get("accounts_sample") or [])[:2]:
            aid  = acc.get("account_id")
            plat = acc.get("platform", "tiktok")
            if aid:
                logger.info(f"Collecte : get_account_info({acc.get('username', aid[:8])})")
                info = get_account_info(plat, acc.get("username") or aid)
                data["accounts_detail"].append({
                    "info":  info,
                    "media": get_media_scores(aid),
                })
    return data


def _collect_post(entry_value: str, neo4j_available: bool) -> dict:
    """Collecte déterministe pour un point d'entrée post."""
    # On cherche le post en MongoDB pour récupérer account_id
    from tools import _get_db
    from bson import ObjectId
    db = _get_db()
    post = db.posts.find_one({"_id": ObjectId(entry_value)})
    if not post:
        return {"error": f"Post introuvable : {entry_value}"}
    account_id = str(post.get("account_id", ""))
    platform   = post.get("platform", "tiktok")
    acc = db.accounts.find_one({"_id": post["account_id"]}, {"username": 1, "platform_id": 1})
    uid = (acc or {}).get("username") or (acc or {}).get("platform_id") or account_id
    return _collect_account(uid, platform, neo4j_available)


# ===========================================================================
# Calcul du score de suspicion global
# ===========================================================================

def compute_suspicion_score(intermediate_steps: list) -> tuple[float, str]:
    """
    Calcule un score de suspicion global [0-1] à partir des résultats
    des outils collectés pendant l'investigation.

    Retourne (score, confidence_label).
    """
    scores       = []
    divergences  = []
    has_campaign = False
    has_reuse    = False

    for _tool_name, observation in intermediate_steps:
        try:
            data = json.loads(observation) if isinstance(observation, str) else observation
        except Exception:
            continue

        # get_account_info → deepfake_summary
        if isinstance(data, dict) and "deepfake_summary" in data:
            ds = data["deepfake_summary"]
            if ds.get("avg_score") is not None:
                scores.append(ds["avg_score"])
            if ds.get("synthetic_ratio") is not None:
                scores.append(ds["synthetic_ratio"])
            if data.get("flags", {}).get("campaign_ids"):
                has_campaign = True

        # get_media_scores → liste de médias
        if isinstance(data, list) and data and "final_score" in (data[0] if data else {}):
            for m in data[:20]:
                if m.get("final_score") is not None:
                    scores.append(m["final_score"])
                if m.get("model_divergence") is not None:
                    divergences.append(m["model_divergence"])
                if (m.get("reuse") or {}).get("seen_count", 1) > 1:
                    has_reuse = True

        # get_campaign_signals → confidence
        if isinstance(data, dict) and "signals" in data:
            conf = (data.get("review") or {}).get("confidence")
            if conf is not None:
                scores.append(float(conf))
            has_campaign = True

        # get_narrative → synthetic_ratio
        if isinstance(data, dict) and "stats" in data and "synthetic_ratio" in (data.get("stats") or {}):
            sr = data["stats"]["synthetic_ratio"]
            if sr is not None:
                scores.append(float(sr))

    # Score de base : moyenne des scores collectés
    base_score = sum(scores) / len(scores) if scores else 0.0

    # Bonus pour signaux de coordination
    if has_campaign:
        base_score = min(1.0, base_score + 0.15)
    if has_reuse:
        base_score = min(1.0, base_score + 0.10)

    # Niveau de confiance selon divergence
    avg_div = sum(divergences) / len(divergences) if divergences else None
    conf_key = divergence_to_confidence(avg_div)
    conf_label = CONFIDENCE_LABELS.get(conf_key, "Moyen")

    return round(base_score, 2), conf_label


# ===========================================================================
# Sauvegarde du rapport
# ===========================================================================

def save_report(
    content:      str,
    reports_dir:  Path,
    entry_type:   str,
    entry_value:  str,
) -> Path:
    """
    Sauvegarde le rapport Markdown dans reports_dir.
    Nom du fichier : YYYY-MM-DD_HHMMSS_<type>_<cible>.md
    """
    reports_dir.mkdir(parents=True, exist_ok=True)

    ts    = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S")
    # Nettoie entry_value pour le nom de fichier
    safe  = re.sub(r"[^\w\-]", "_", entry_value)[:40]
    fname = f"{ts}_{entry_type}_{safe}.md"
    path  = reports_dir / fname

    path.write_text(content, encoding="utf-8")
    return path



def _build_llm_context(raw_data: dict, suspicion_score: float, confidence: str, neo4j_available: bool) -> str:
    """
    Construit un résumé compact et structuré des données collectées
    pour le LLM — évite la saturation du contexte avec du JSON brut.
    """
    lines = []

    # --- Compte ---
    acc = raw_data.get("account", {})
    if acc and "error" not in acc:
        lines.append("## COMPTE ANALYSÉ")
        lines.append(f"- Plateforme     : {acc.get('platform', 'N/A')}")
        lines.append(f"- Username       : {acc.get('display_name') or acc.get('username', 'N/A')}")
        lines.append(f"- URL            : {acc.get('url', 'N/A')}")
        lines.append(f"- Vérifié        : {acc.get('profile', {}).get('verified', False)}")
        lines.append(f"- Followers      : {acc.get('stats', {}).get('followers_count', 0)}")
        ds = acc.get("deepfake_summary", {})
        if ds:
            lines.append(f"- Posts analysés : {ds.get('posts_analyzed', 0)}")
            lines.append(f"- Score deepfake moyen : {ds.get('avg_score', 'N/A')}")
            lines.append(f"- Posts synthétiques   : {ds.get('synthetic_count', 0)} ({ds.get('synthetic_ratio', 0)*100:.1f}%)")
            lines.append(f"- Posts suspects       : {ds.get('suspicious_count', 0)}")
        flags = acc.get("flags", {})
        lines.append(f"- Suspect flagué : {flags.get('is_suspicious', False)}")
        lines.append(f"- Campagnes liées: {len(flags.get('campaign_ids', []))}")
        lines.append("")

    # --- Posts (top 5) ---
    posts = raw_data.get("posts", [])
    if posts:
        lines.append("## DERNIERS POSTS (top 5 sur {})".format(len(posts)))
        for p in posts[:5]:
            df = p.get("deepfake", {})
            nlp = p.get("nlp", {})
            sent = nlp.get("sentiment", {})
            lines.append(f"- [{p.get('published_at', '')[:10]}] score={df.get('score', 'N/A')} pred={df.get('prediction', 'N/A')} div={df.get('divergence', 'N/A')} sentiment={sent.get('label', 'N/A')} | {p.get('text_preview', '')[:80]}")
        lines.append("")

    # --- Médias (stats agrégées) ---
    media = raw_data.get("media", [])
    if media:
        lines.append("## MÉDIAS ANALYSÉS ({} médias)".format(len(media)))
        scores = [m.get("final_score") for m in media if m.get("final_score") is not None]
        divs   = [m.get("model_divergence") for m in media if m.get("model_divergence") is not None]
        synth  = [m for m in media if m.get("prediction") == "synthetic"]
        susp   = [m for m in media if m.get("prediction") == "suspicious"]
        reused = [m for m in media if (m.get("reuse") or {}).get("seen_count", 1) > 1]
        if scores:
            lines.append(f"- Score moyen          : {sum(scores)/len(scores):.3f}")
            lines.append(f"- Score max            : {max(scores):.3f}")
        if divs:
            lines.append(f"- Divergence moyenne   : {sum(divs)/len(divs):.3f}")
        lines.append(f"- Synthétiques         : {len(synth)} ({len(synth)/len(media)*100:.1f}%)")
        lines.append(f"- Suspects             : {len(susp)} ({len(susp)/len(media)*100:.1f}%)")
        lines.append(f"- Médias réutilisés    : {len(reused)}")
        # Top 3 médias par score
        top3 = sorted(media, key=lambda m: m.get("final_score") or 0, reverse=True)[:3]
        lines.append("- Top 3 scores :")
        for m in top3:
            df = m.get("scores_by_model", {})
            lines.append(f"  * score={m.get('final_score')} div={m.get('model_divergence')} sdxl={df.get('sdxl-detector','?')} swinv2={df.get('swinv2-openfake','?')} synth={df.get('synthbuster','?')}")
        lines.append("")

    # --- Graphe Neo4j ---
    graph = raw_data.get("graph", {})
    if graph and "error" not in graph:
        s = graph.get("summary", {})
        lines.append("## RÉSEAU NEO4J")
        lines.append(f"- Comptes même communauté Louvain : {s.get('community_size', 0)}")
        lines.append(f"- Comptes partageant ≥2 hashtags  : {s.get('shared_hashtag_accounts', 0)}")
        lines.append(f"- Sources de duplication (copie de) : {s.get('duplicate_sources', 0)}")
        lines.append(f"- Comptes copiant ce compte        : {s.get('copiers', 0)}")
        lines.append(f"- Hashtags distincts utilisés      : {s.get('hashtag_count', 0)}")
        lines.append(f"- Narratives liées                 : {s.get('narrative_count', 0)}")
        lines.append(f"- Campagnes détectées              : {s.get('campaign_count', 0)}")

        # Communauté Louvain
        community = graph.get("community_accounts", [])
        if community:
            lines.append(f"- Communauté ({len(community)} comptes, top 5 par PageRank) :")
            for n in community[:5]:
                susp = " ⚠️ suspect" if n.get("is_suspicious") else ""
                lines.append(f"  * {n.get('username','?')} ({n.get('platform','?')}) pagerank={n.get('pagerank','?')}{susp}")

        # Comptes partageant des hashtags
        sha = graph.get("shared_hashtag_accounts", [])
        if sha:
            lines.append(f"- Comptes avec hashtags communs (top 5) :")
            for n in sha[:5]:
                lines.append(f"  * {n.get('username','?')} ({n.get('platform','?')}) — {n.get('shared_tags','?')} hashtags en commun")

        # Duplication de contenu
        dup_from = graph.get("duplicated_from", [])
        if dup_from:
            lines.append(f"- Ce compte copie du contenu de :")
            for d in dup_from[:5]:
                lines.append(f"  * {d.get('username','?')} ({d.get('platform','?')}) — {d.get('duplicate_count','?')} posts copiés")
        copied_by = graph.get("copied_by", [])
        if copied_by:
            lines.append(f"- Ce compte est copié par :")
            for d in copied_by[:5]:
                lines.append(f"  * {d.get('username','?')} ({d.get('platform','?')}) — {d.get('copy_count','?')} copies")

        # Hashtags fréquents
        hashtags = graph.get("shared_hashtags", [])
        if hashtags:
            lines.append("- Hashtags fréquents : " + ", ".join(
                f"#{h.get('tag','?')}({h.get('usage','?')})" for h in hashtags[:10]
            ))

        # Narratives et campagnes
        narratives_g = graph.get("narratives", [])
        if narratives_g:
            lines.append(f"- Narratives ({len(narratives_g)}) :")
            for n in narratives_g[:5]:
                camp_info = f" → Campagne: {n.get('campaign_name','?')} (score={n.get('campaign_score','?')})" if n.get('campaign_name') else ""
                lines.append(f"  * {n.get('label','?')} — {n.get('account_posts','?')} posts{camp_info}")

        campaigns_g = graph.get("campaigns", [])
        if campaigns_g:
            lines.append(f"- CAMPAGNES DÉTECTÉES ({len(campaigns_g)}) :")
            for c in campaigns_g:
                lines.append(f"  * {c.get('name','?')} score={c.get('score','?')} signaux={c.get('signal_count','?')}")
        lines.append("")
    else:
        lines.append("## RÉSEAU NEO4J")
        lines.append("- Relations non encore synchronisées dans Neo4j (ETL en attente)")
        lines.append("")

    # --- Narrative principale (pour --narrative) ---
    narrative = raw_data.get("narrative", {})
    if narrative and "error" not in narrative:
        lines.append("## NARRATIVE ANALYSÉE")
        stats = narrative.get("stats", {})
        lines.append(f"- Label          : {narrative.get('label', 'N/A')}")
        lines.append(f"- Posts          : {stats.get('post_count', 'N/A')}")
        lines.append(f"- Comptes        : {stats.get('account_count', 'N/A')}")
        lines.append(f"- Ratio synth.   : {stats.get('synthetic_ratio', 'N/A')}")
        lines.append(f"- Plateformes    : {', '.join(stats.get('platforms', []))}")
        lines.append(f"- Mots-clés      : {', '.join(narrative.get('keywords', [])[:8])}")
        lines.append(f"- Première vue   : {str(stats.get('first_seen_at', ''))[:10]}")
        lines.append(f"- Dernière vue   : {str(stats.get('last_seen_at', ''))[:10]}")
        top = narrative.get("top_accounts", [])
        if top:
            lines.append(f"- Top comptes ({len(top)}) :")
            for a in top[:5]:
                lines.append(f"  * {a.get('username','?')} ({a.get('platform','?')}) — {a.get('post_count','?')} posts, score deepfake moyen: {a.get('avg_deepfake_score','N/A')}")
        lines.append("")

    # --- Comptes associés à la narrative (pour --narrative) ---
    accounts_list = raw_data.get("accounts_list", [])
    if accounts_list:
        lines.append("## COMPTES PORTANT LA NARRATIVE ({})".format(len(accounts_list)))
        for a in accounts_list[:10]:
            ns = a.get("narrative_stats", {})
            lines.append(f"- @{a.get('display_name') or a.get('username','?')} ({a.get('platform','?')})")
            lines.append(f"  Posts: {ns.get('post_count','?')} | Synthétiques: {ns.get('synthetic_posts','?')} ({ns.get('synthetic_ratio',0)*100:.1f}%) | Score moyen: {ns.get('avg_deepfake_score','N/A')}")
        lines.append("")

    # --- Campagne MongoDB (pour --campaign) ---
    campaign = raw_data.get("campaign", {})
    if campaign and "error" not in campaign:
        sig = campaign.get("signals", {})
        rev = campaign.get("review", {})
        lines.append("## CAMPAGNE — SIGNAUX MONGODB")
        lines.append(f"- Nom            : {campaign.get('name', 'N/A')}")
        lines.append(f"- Statut         : {campaign.get('status', 'N/A')}")
        lines.append(f"- Confiance      : {rev.get('confidence', 'N/A')}")
        lines.append(f"- Confirmée      : {rev.get('confirmed', False)}")
        lines.append(f"- Posting coordonné    : {sig.get('coordinated_posting', 'N/A')}")
        lines.append(f"- Réutilisation contenu: {sig.get('content_reuse', 'N/A')}")
        lines.append(f"- Ratio bots           : {sig.get('bot_accounts_ratio', 'N/A')}")
        lines.append(f"- Ratio médias synth.  : {sig.get('synthetic_media_ratio', 'N/A')}")
        lines.append(f"- Cross-plateforme     : {sig.get('cross_platform', 'N/A')}")
        lines.append(f"- Burst Telegram       : {sig.get('telegram_forward_burst', 'N/A')}")
        lines.append(f"- Notes          : {rev.get('notes', '')}")
        lines.append("")

    # --- Graphe de la campagne Neo4j (pour --campaign) ---
    cg = raw_data.get("campaign_graph", {})
    if cg and "error" not in cg:
        s = cg.get("summary", {})
        lines.append("## CAMPAGNE — GRAPHE NEO4J")
        lines.append(f"- Comptes impliqués   : {s.get('account_count', 0)}")
        lines.append(f"- Plateformes         : {', '.join(s.get('platforms', []))}")
        lines.append(f"- Cross-plateforme    : {s.get('has_cross_platform', False)}")
        lines.append(f"- Total posts         : {s.get('total_posts', 0)}")
        lines.append(f"- Doublons détectés   : {s.get('total_duplicates', 0)}")
        lines.append(f"- Score deepfake moyen: {s.get('avg_deepfake_score', 'N/A')}")
        # Narratives
        for n in cg.get("narratives", []):
            lines.append(f"- Narrative : {n.get('label','?')} ({n.get('post_count','?')} posts)")
            lines.append(f"  Mots-clés : {', '.join((n.get('keywords') or [])[:8])}")
            lines.append(f"  Signaux   : {', '.join(n.get('signals') or [])}")
        # Comptes avec stats
        lines.append(f"- Comptes ({len(cg.get('accounts', []))}) :")
        for a in cg.get("accounts", []):
            susp = " SUSPECT" if a.get("is_suspicious") else ""
            avg_df = round(a.get("avg_deepfake"), 3) if a.get("avg_deepfake") else "N/A"
            lines.append(
                f"  * @{a.get('username','?')} ({a.get('platform','?')}) "
                f"posts={a.get('post_count',0)} deepfake={avg_df} "
                f"doublons={a.get('duplicate_count',0)} "
                f"community={a.get('community_id','?')}{susp}"
            )
        # Hashtags dominants
        htags = cg.get("hashtags", [])
        if htags:
            lines.append("- Hashtags dominants : " + ", ".join(
                f"#{h.get('hashtag','?')}({h.get('usage','?')})" for h in htags[:12]
            ))
        # Duplication de contenu
        dups = cg.get("duplicates", [])
        if dups:
            lines.append(f"- Duplication de contenu ({len(dups)} paires) :")
            for d in dups:
                lines.append(
                    f"  * @{d.get('copier','?')} ({d.get('copier_platform','?')}) "
                    f"copie @{d.get('original_author','?')} ({d.get('original_platform','?')}) "
                    f"— {d.get('copies','?')} fois"
                )
        # Communautés Louvain
        comms = cg.get("communities", [])
        if len(comms) > 1:
            lines.append(
                f"- Communautés Louvain : {len(comms)} communautés distinctes "
                f"({'coordination faible' if len(comms) > 3 else 'coordination possible'})"
            )
        lines.append("")

    # --- Comptes détaillés (pour --narrative et --campaign) ---
    accounts_detail = raw_data.get("accounts_detail", [])
    if accounts_detail:
        lines.append("## COMPTES ANALYSÉS EN DÉTAIL ({})".format(len(accounts_detail)))
        for entry in accounts_detail:
            info = entry.get("info", {})
            media = entry.get("media", [])
            if "error" in info:
                continue
            ds = info.get("deepfake_summary", {})
            lines.append(f"- @{info.get('display_name') or info.get('username','?')} ({info.get('platform','?')})")
            lines.append(f"  Posts analysés: {ds.get('posts_analyzed','?')} | Score moyen: {ds.get('avg_score','N/A')} | Synthétiques: {ds.get('synthetic_count',0)}")
            if media:
                m_scores = [m.get("final_score") for m in media if m.get("final_score") is not None]
                m_synth  = [m for m in media if m.get("prediction") == "synthetic"]
                lines.append(f"  Médias: {len(media)} | Score moy: {sum(m_scores)/len(m_scores):.3f if m_scores else 'N/A'} | Synthétiques: {len(m_synth)}")
        lines.append("")

    # --- Narratives liées à un compte (pour --account) ---
    narratives = raw_data.get("narratives", [])
    if narratives:
        lines.append("## NARRATIVES ({} identifiées)".format(len(narratives)))
        for n in narratives:
            if "error" not in n:
                stats = n.get("stats", {})
                lines.append(f"- {n.get('label', 'N/A')}")
                lines.append(f"  Posts: {stats.get('post_count', 'N/A')} | Ratio synthétique: {stats.get('synthetic_ratio', 'N/A')}")
                lines.append(f"  Mots-clés: {', '.join(n.get('keywords', [])[:6])}")
        lines.append("")

    # --- Analyse temporelle ---
    temporal = raw_data.get("temporal", {})
    if temporal and "error" not in temporal:
        s = temporal.get("summary", {})
        lines.append("## ANALYSE TEMPORELLE")

        # Vue d'ensemble
        lines.append(f"- Période couverte        : {s.get('first_post','?')} → {s.get('last_post','?')}")
        lines.append(f"- Jours d'activité totaux : {s.get('total_days_active', 0)}")
        lines.append(f"- Jours de co-occurrence  : {s.get('cooccurrence_days', 0)}")
        lines.append(f"- Co-occurrence max        : {s.get('max_cooccurrence', 0)} comptes le même jour")

        # Compte semence
        seed = temporal.get("seed_account")
        if seed:
            lines.append(
                f"- COMPTE SEMENCE : @{seed.get('account','?')} ({seed.get('platform','?')}) "
                f"— premier post le {str(seed.get('first_pub',''))[:10]} "
                f"({seed.get('posts',0)} posts au total)"
            )

        # Comptes robotiques
        robotic = s.get("robotic_accounts", [])
        if robotic:
            lines.append(f"- Cadence robotique détectée : {', '.join('@'+r for r in robotic)}")

        # Silences suspects
        silences = temporal.get("silences", {})
        if silences:
            lines.append("- Silences suspects (gaps > 14 jours) :")
            for acc, gaps in silences.items():
                for g in gaps[:2]:
                    lines.append(
                        f"  * @{acc} : {g.get('gap_start','?')} → {g.get('gap_end','?')} "
                        f"({g.get('days','?')} jours) — possible rotation de gestionnaire"
                    )

        # Mois de pic
        peaks = s.get("peak_months", [])
        if peaks:
            lines.append(f"- Mois de forte accélération : {', '.join(peaks)}")

        # Corrélation deepfake × temporel
        df_spikes = temporal.get("deepfake_temporal", [])
        if df_spikes:
            lines.append("- Pics de deepfake corrélés aux pics d'activité :")
            for m in df_spikes:
                lines.append(
                    f"  * {m.get('month','?')} : score deepfake moy={round((m.get('avg_deepfake') or 0), 3)} "
                    f"sur {m.get('posts',0)} posts ({m.get('synthetic_count',0)} synthétiques)"
                )
        else:
            lines.append("- Corrélation deepfake × temporel : aucun pic deepfake corrélé")

        # Cross-campagne
        cross = temporal.get("cross_campaign", [])
        if cross:
            lines.append(f"- Amplificateurs cross-campagne ({len(cross)}) :")
            for x in cross[:5]:
                if "other_campaigns" in x:
                    lines.append(
                        f"  * @{x.get('account','?')} ({x.get('platform','?')}) "
                        f"— actif sur {x.get('campaign_count','?')} autres campagnes"
                    )
                else:
                    lines.append(
                        f"  * Campagne : {str(x.get('campaign','?'))[:50]} "
                        f"(score={x.get('score','?')}, {x.get('posts',0)} posts)"
                    )

        # Propagation chronologique
        prop = temporal.get("propagation", [])
        if prop:
            lines.append("- Chronologie d'entrée des comptes :")
            for p in prop:
                lines.append(
                    f"  * @{p.get('account','?')} ({p.get('platform','?')}) : "
                    f"entrée {str(p.get('first_post',''))[:10]} — "
                    f"sortie {str(p.get('last_post',''))[:10]} — "
                    f"{p.get('total_posts',0)} posts"
                )

        # Top jours de co-occurrence
        coocs = temporal.get("cooccurrences", [])
        if coocs:
            lines.append(f"- Top jours de publication simultanée :")
            for c in coocs[:5]:
                accs = ", ".join(f"@{a}" for a in (c.get("accounts_list") or [])[:4])
                lines.append(
                    f"  * {c.get('day','?')} : {c.get('active_accounts','?')} comptes, "
                    f"{c.get('total_posts','?')} posts → {accs}"
                )

        # Cadence
        cadence = temporal.get("cadence", [])
        if cadence:
            lines.append("- Cadence de publication :")
            for c in cadence:
                avg = round(c.get("avg_per_day") or 0, 2)
                lines.append(
                    f"  * @{c.get('account','?')} ({c.get('platform','?')}) : "
                    f"{c.get('active_days',0)} jours actifs, "
                    f"moy={avg}/jour, max={c.get('max_per_day',0)}/jour"
                )

        # Évolution mensuelle avec deepfake
        monthly = temporal.get("monthly", [])
        if monthly:
            lines.append("- Évolution mensuelle (posts | comptes | deepfake moy) :")
            for m in monthly[-18:]:
                df_val = round(m.get("avg_deepfake") or 0, 3)
                bar = "█" * min(int(m.get("posts", 0) / 2), 15)
                lines.append(
                    f"  {m.get('month','?')} : {str(m.get('posts',0)).rjust(3)} posts "
                    f"| {m.get('accounts',0)} comptes "
                    f"| deepfake={df_val} {bar}"
                )
        lines.append("")

    # --- Score global ---
    lines.append("## MÉTRIQUES CALCULÉES")
    lines.append(f"- Score de suspicion global : {suspicion_score} / 1.0")
    lines.append(f"- Niveau de confiance       : {confidence}")
    lines.append(f"- Neo4j disponible          : {neo4j_available}")
    lines.append("")

    return "\n".join(lines)

# ===========================================================================
# Runner principal — mode déterministe
# ===========================================================================

def run_investigation(
    entry_type:  str,
    entry_value: str,
    platform:    Optional[str],
    cfg:         AgentConfig,
    verbose:     bool = False,
) -> str:
    """
    Lance l'investigation complète en mode déterministe :
      1. Collecte les données via les outils Python (séquence fixe)
      2. Calcule le score de suspicion
      3. Demande au LLM de rédiger le rapport à partir des données réelles

    Args:
        entry_type  : account | post | narrative | campaign
        entry_value : identifiant de la cible
        platform    : plateforme (obligatoire pour account)
        cfg         : configuration LLM
        verbose     : active les logs détaillés

    Returns:
        str — rapport Markdown complet
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    logger.info("=" * 60)
    logger.info(f"Investigation : {entry_type} — {entry_value}")
    if platform:
        logger.info(f"Plateforme    : {platform}")
    logger.info(f"Modèle        : {cfg.provider}/{cfg.model}")
    logger.info("=" * 60)

    # --- Étape 1 : vérification Neo4j ---
    neo4j_available = True
    try:
        from tools import _get_neo4j
        neo4j_available = _get_neo4j() is not None
    except Exception:
        neo4j_available = False
    if not neo4j_available:
        logger.warning("Neo4j indisponible — investigation MongoDB uniquement")

    # --- Étape 2 : collecte déterministe des données ---
    logger.info("Phase 1 : collecte des données...")
    if entry_type == "account":
        raw_data = _collect_account(entry_value, platform, neo4j_available)
    elif entry_type == "narrative":
        raw_data = _collect_narrative(entry_value, neo4j_available)
    elif entry_type == "campaign":
        raw_data = _collect_campaign(entry_value)
    elif entry_type == "post":
        raw_data = _collect_post(entry_value, neo4j_available)
    else:
        raw_data = {}

    logger.info(f"Collecte terminée — {len(raw_data)} sections récupérées")

    # --- Étape 3 : calcul du score de suspicion ---
    # On reconstruit intermediate_steps depuis raw_data pour réutiliser compute_suspicion_score
    intermediate = []
    if "account" in raw_data:
        intermediate.append(("get_account_info", json.dumps(raw_data["account"], default=str)))
    if "media" in raw_data:
        intermediate.append(("get_media_scores", json.dumps(raw_data["media"], default=str)))
    if "campaign" in raw_data:
        intermediate.append(("get_campaign_signals", json.dumps(raw_data["campaign"], default=str)))
    for narr in raw_data.get("narratives", []):
        intermediate.append(("get_narrative", json.dumps(narr, default=str)))

    suspicion_score, confidence = compute_suspicion_score(intermediate)
    logger.info(f"Score de suspicion : {suspicion_score} (confiance : {confidence})")

    # --- Étape 4 : rédaction du rapport par le LLM ---
    logger.info("Phase 2 : rédaction du rapport par le LLM...")
    llm = build_llm(cfg)

    system = build_system_prompt(neo4j_available=neo4j_available)

    # Construit un résumé compact structuré (pas de JSON brut)
    ctx = _build_llm_context(raw_data, suspicion_score, confidence, neo4j_available)

    # --- Cible lisible selon le type d'entrée ---
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S UTC")

    if entry_type == "account":
        acc = raw_data.get("account", {})
        target_label    = acc.get("display_name") or acc.get("username") or entry_value
        target_platform = acc.get("platform") or platform or ""
        target_header   = f"@{target_label} ({target_platform})"
        subject_desc    = f"le compte @{target_label} sur {target_platform}"
        sections = """## Synthèse
[3-5 phrases résumant l'activité du compte, les scores deepfake, la cadence de publication et l'évaluation globale]

## Analyse des médias
[Statistiques réelles : nombre de médias, scores moyens, ratio synthétique, divergence inter-modèles, interprétation du pattern sdxl vs swinv2]

## Analyse temporelle
[Habitudes de publication : cadence, régularité, jours/heures actifs, silences suspects, participation à plusieurs campagnes. Utilise les données ANALYSE TEMPORELLE.]

## Position dans le réseau
[Données Neo4j : communauté Louvain, comptes partageant des hashtags, duplications de contenu, campagnes liées]

## Narratives portées
[Narratives identifiées avec mots-clés, nombre de posts, ratio synthétique]

## Signaux de coordination
[Signaux détectés : co-occurrence temporelle, duplication, hashtags partagés, ou absence explicite]

## Conclusion
[Qualification : campagne probable / viralité organique / insuffisant pour conclure]

## Requêtes Cypher suggérées
Propose 3 requêtes Cypher Neo4j Browser exploitables. Utilise UNIQUEMENT ces relations réelles et cette syntaxe exacte (pas de GROUP BY, pas de JOIN — c'est du Cypher pas du SQL) :

Syntaxe correcte pour compter et grouper :
```cypher
// Compter les hashtags d'un compte (CORRECT)
MATCH (a:Account {display_name: "nom_compte"})-[:A_PUBLIÉ]->(p:Post)-[:HAS_HASHTAG]->(h:Hashtag)
RETURN h.name AS hashtag, count(p) AS usage
ORDER BY usage DESC LIMIT 15
```

Relations disponibles : A_PUBLIÉ, EST_DOUBLON_DE, HAS_HASHTAG, APPARTIENT_À, COUVRE
Propriétés Account : display_name, platform, community_id, pagerank_score
Propriétés Post : published_at, deepfake_score, is_duplicate, sentiment_label, text

Propose 3 requêtes utiles pour ce compte en utilisant son vrai display_name. Format : bloc cypher + une ligne d'explication.

## Recommandations
[2-4 points concrets et actionnables]"""

    elif entry_type == "narrative":
        narr = raw_data.get("narrative", {})
        target_label    = narr.get("label") or entry_value
        target_platform = ""
        target_header   = f"Narrative — {target_label}"
        subject_desc    = f'la narrative "{target_label}"'
        sections = """## Synthèse
[3-5 phrases résumant la narrative : contenu, portée, ratio synthétique, comptes impliqués, période couverte]

## Comptes portant la narrative
[Liste et analyse des comptes identifiés : scores deepfake, ratio synthétique, plateformes]

## Analyse temporelle
[Propagation : quel compte a publié en premier, jours de co-occurrence, cadences de publication, accélérations. Utilise les données ANALYSE TEMPORELLE.]

## Analyse des médias
[Statistiques deepfake des comptes les plus actifs si disponibles]

## Signaux de coordination
[Signaux détectés : duplication de contenu, co-occurrence temporelle, hashtags partagés]

## Conclusion
[Qualification : narrative coordonnée / viralité organique / insuffisant pour conclure]

## Requêtes Cypher suggérées
Propose 3 requêtes Cypher Neo4j Browser exploitables. Syntaxe obligatoire (Cypher, pas SQL — pas de GROUP BY) :

```cypher
// Comptes actifs sur une narrative (CORRECT)
MATCH (n:Narrative {label: "label_narrative"})<-[:APPARTIENT_À]-(p:Post)<-[:A_PUBLIÉ]-(a:Account)
RETURN a.display_name AS compte, a.platform AS plateforme, count(p) AS posts
ORDER BY posts DESC

// Doublons dans une narrative (CORRECT)
MATCH (n:Narrative {label: "label_narrative"})<-[:APPARTIENT_À]-(p:Post)-[:EST_DOUBLON_DE]->(orig:Post)
MATCH (p)<-[:A_PUBLIÉ]-(copier:Account), (orig)<-[:A_PUBLIÉ]-(source:Account)
RETURN copier.display_name AS copie, source.display_name AS source, count(*) AS nb
ORDER BY nb DESC
```

Relations disponibles : A_PUBLIÉ, EST_DOUBLON_DE, HAS_HASHTAG, APPARTIENT_À, COUVRE
Propose 3 requêtes utiles pour cette narrative. Format : bloc cypher + une ligne d'explication.

## Recommandations
[2-4 points concrets et actionnables]"""

    elif entry_type == "campaign":
        camp = raw_data.get("campaign", {})
        target_label    = camp.get("name") or entry_value
        target_platform = ""
        target_header   = f"Campagne — {target_label}"
        subject_desc    = f'la campagne détectée "{target_label}"'
        sections = """## Synthèse
[3-5 phrases résumant la campagne : signaux détectés, nombre de comptes, confiance, narratives liées, période couverte]

## Signaux de coordination
[Analyse détaillée : posting coordonné, réutilisation de contenu, ratio synthétique, cross-plateforme, doublons entre comptes]

## Analyse temporelle
[Propagation chronologique : quel compte a publié en premier, jours de co-occurrence multi-comptes, cadences robotiques, mois de forte accélération. Utilise les données ANALYSE TEMPORELLE.]

## Comptes membres
[Analyse des comptes : posts, scores deepfake, doublons, communautés Louvain, comportements suspects]

## Analyse des médias
[Statistiques deepfake des comptes membres si disponibles]

## Conclusion
[Qualification : campagne coordonnée confirmée / probable / insuffisant pour conclure. Appuie-toi sur les signaux temporels et de duplication.]

## Requêtes Cypher suggérées
Propose 4 requêtes Cypher Neo4j Browser exploitables. Syntaxe obligatoire (Cypher, pas SQL — pas de GROUP BY, utiliser WITH + count()) :

```cypher
// Réseau complet d'une campagne (CORRECT)
MATCH path = (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)<-[:A_PUBLIÉ]-(a:Account)
WHERE c.mongo_id = "id_campagne"
RETURN path LIMIT 100

// Propagation chronologique (CORRECT)
MATCH (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)<-[:A_PUBLIÉ]-(a:Account)
WHERE c.mongo_id = "id_campagne" AND p.published_at IS NOT NULL
RETURN a.display_name AS compte, p.published_at AS date, p.text AS texte
ORDER BY p.published_at LIMIT 50

// Hashtags dominants (CORRECT — pas de GROUP BY)
MATCH (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)-[:HAS_HASHTAG]->(h:Hashtag)
WHERE c.mongo_id = "id_campagne"
RETURN h.name AS hashtag, count(p) AS usage
ORDER BY usage DESC LIMIT 15

// Doublons entre comptes (CORRECT)
MATCH (c:Campaign)-[:COUVRE]->(n:Narrative)<-[:APPARTIENT_À]-(p:Post)-[:EST_DOUBLON_DE]->(orig:Post)
WHERE c.mongo_id = "id_campagne"
MATCH (p)<-[:A_PUBLIÉ]-(copier:Account), (orig)<-[:A_PUBLIÉ]-(source:Account)
RETURN copier.display_name AS copie, source.display_name AS source, count(*) AS copies
ORDER BY copies DESC
```

Adapte ces 4 requêtes avec le vrai mongo_id de la campagne et les vrais display_name des comptes issus des données. Remplace les placeholders par les vraies valeurs.

## Recommandations
[2-4 points concrets et actionnables]"""

    else:
        acc = raw_data.get("account", {})
        target_label    = acc.get("display_name") or acc.get("username") or entry_value
        target_platform = acc.get("platform") or platform or ""
        target_header   = f"@{target_label} ({target_platform})"
        subject_desc    = f"la cible {target_label}"
        sections = """## Synthèse
[Résumé de l'investigation]

## Conclusion
[Qualification]

## Recommandations
[Points actionnables]"""

    user_prompt = f"""Tu dois rédiger un rapport d'investigation complet en Markdown sur {subject_desc}.

## Données collectées et métriques

{ctx}

## Instructions

Rédige le rapport en français avec exactement ces sections :

# Rapport d'investigation — {target_header}
**Date :** {now_str}
**Score de suspicion global :** {suspicion_score} / 1.0
**Niveau de confiance :** {confidence}

---

{sections}

RÈGLES STRICTES :
- Utilise uniquement les valeurs numériques fournies dans les données ci-dessus
- Ne pas inventer de dates, scores, noms ou identifiants
- Si une donnée est manquante, l'indiquer explicitement sans l'inventer
- La date du rapport est {now_str}

AVERTISSEMENT DONNÉES PARTIELLES :
Le scrapping sur lequel repose cette analyse n'est pas nécessairement exhaustif.
Les données disponibles représentent un échantillon de l'activité réelle — il existe
probablement des comptes, posts, médias et relations non capturés. Mentionne
systématiquement dans la synthèse et la conclusion que l'analyse s'appuie sur
des données potentiellement partielles, et que les signaux détectés peuvent être
sous-estimés ou sur-représentés par rapport à la réalité.
"""

    from langchain_core.messages import HumanMessage, SystemMessage
    response = llm.invoke([
        SystemMessage(content=system),
        HumanMessage(content=user_prompt),
    ])

    report_content = response.content if hasattr(response, "content") else str(response)

    # --- Étape 5 : ajout du score et disclaimer ---
    if "Score de suspicion" not in report_content:
        header = (
            f"**Score de suspicion global :** {suspicion_score} / 1.0  \n"
            f"**Niveau de confiance :** {confidence}\n\n"
        )
        report_content = header + report_content

    disclaimer = (
        "\n\n---\n"
        f"*Rapport généré automatiquement par AI-FORENSICS Investigation Agent*  \n"
        f"*Modèle : {cfg.model} via {cfg.provider} — Ce rapport nécessite une vérification humaine.*  \n"
        f"*Les scores deepfake sont des indicateurs probabilistes, pas des preuves.*  \n"
        f"*⚠️ Données potentiellement partielles : le scrapping peut être incomplet. "
        f"Les signaux détectés s'appuient sur un échantillon de l'activité réelle.*"
    )
    if "vérification humaine" not in report_content:
        report_content += disclaimer

    return report_content


# ===========================================================================
# CLI
# ===========================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Agent d'investigation AI-FORENSICS",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemples :
  # Analyser un compte TikTok
  python investigation_agent.py --account nolimitmoneyy0 --platform tiktok

  # Analyser une narrative
  python investigation_agent.py --narrative 69d2774d7dc202593e1b35fa

  # Analyser une campagne
  python investigation_agent.py --campaign <campaign_id>

  # Avec options
  python investigation_agent.py --account nolimitmoneyy0 --platform tiktok \\
      --output ~/AI-FORENSICS/reports --model llama3.1:8b --verbose
        """,
    )

    # Points d'entrée (mutuellement exclusifs)
    entry = parser.add_mutually_exclusive_group(required=True)
    entry.add_argument("--account",   metavar="UNIQUE_ID",
                       help="@handle ou platform_id du compte à analyser")
    entry.add_argument("--narrative", metavar="NARRATIVE_ID",
                       help="_id MongoDB de la narrative")
    entry.add_argument("--campaign",  metavar="CAMPAIGN_ID",
                       help="_id MongoDB de la campagne")
    entry.add_argument("--post",      metavar="POST_ID",
                       help="_id MongoDB du post")

    # Options compte
    parser.add_argument("--platform", default=None,
                        choices=["tiktok", "instagram", "twitter", "telegram"],
                        help="Plateforme (obligatoire avec --account)")

    # Options LLM
    parser.add_argument("--provider", default=None,
                        choices=["ollama", "groq", "anthropic"],
                        help="Provider LLM (défaut : $AI_PROVIDER ou ollama)")
    parser.add_argument("--model",    default=None,
                        help="Modèle LLM (défaut : $AI_MODEL ou llama3.1:8b)")
    parser.add_argument("--temperature", type=float, default=None,
                        help="Température LLM (défaut : 0.2)")

    # Options sortie
    parser.add_argument("--output",  default=None, metavar="DIR",
                        help="Dossier de sortie des rapports (défaut : ../reports/)")
    parser.add_argument("--no-save", action="store_true",
                        help="Affiche le rapport sans le sauvegarder")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Logs détaillés")

    args = parser.parse_args()

    # Validation
    if args.account and not args.platform:
        parser.error("--platform est obligatoire avec --account")

    # Détermine le point d'entrée
    if args.account:
        entry_type  = "account"
        entry_value = args.account
    elif args.narrative:
        entry_type  = "narrative"
        entry_value = args.narrative
    elif args.campaign:
        entry_type  = "campaign"
        entry_value = args.campaign
    elif args.post:
        entry_type  = "post"
        entry_value = args.post

    # Configuration
    cfg = AgentConfig(
        provider    = args.provider,
        model       = args.model,
        output_dir  = args.output,
        temperature = args.temperature,
    )

    if args.verbose:
        logger.info(f"Config : {cfg}")

    # Lance l'investigation
    try:
        report = run_investigation(
            entry_type  = entry_type,
            entry_value = entry_value,
            platform    = args.platform,
            cfg         = cfg,
            verbose     = args.verbose,
        )
    except KeyboardInterrupt:
        logger.info("Investigation interrompue par l'utilisateur.")
        sys.exit(0)
    except Exception as exc:
        logger.error(f"Erreur fatale : {exc}", exc_info=True)
        sys.exit(1)

    # Affichage
    print("\n" + "=" * 60)
    print(report)
    print("=" * 60)

    # Sauvegarde
    if not args.no_save:
        path = save_report(
            content     = report,
            reports_dir = cfg.reports_dir,
            entry_type  = entry_type,
            entry_value = entry_value,
        )
        logger.info(f"Rapport sauvegardé : {path}")
        print(f"\n✓ Rapport sauvegardé : {path}")


if __name__ == "__main__":
    main()
